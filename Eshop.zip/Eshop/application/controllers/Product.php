<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Product extends CI_controller{
function __construct(){
		parent:: __construct();
		$this->load->model('product_model', 'm');
	}

public function products(){

 	$data['products']=$this->m->showAllProduct();

	$this->load->view('header/headeradmin');
	 	
	$this->load->view('products/products',$data);

	$this->load->view('header/footer');

}




public function showAllProduct(){

		$result = $this->m->showAllProduct();
		echo json_encode($result);

}
public function showCart(){

		$result = $this->m->show_cart();
		echo json_encode($result);

}

public function showallCart(){

		$result = $this->m->show_allCart();
		echo json_encode($result);

}
public function addtocart(){
	$result = $this->m->add_Cart();
		$msg['success'] = false;
		$msg['type'] = 'update';
		if($result){
			$msg['success'] = true;
		}
		echo json_encode($msg);



}

public function addCart(){
		$result = $this->m->add_Cart();
		$msg['success'] = false;
		$msg['type'] = 'update';
		if($result){
			$msg['success'] = true;
		}
		echo json_encode($msg);
}


public function showTotal(){

	$result = $this->m->show_Total();
		echo json_encode($result);

}
public function showTotalv1(){

	$result = $this->m->show_Totalv1();
		echo json_encode($result);

}
public function checkOut(){
$product=$this->input->post('product');
$minus=$this->input->post('minus');




	$result = $this->m->check_Out($product,$minus);
	
		echo json_encode($result);


}


public function addProduct(){



			$config['upload_path']='./assets/image/upload';
			$config['allowed_types']='.png|jpg|jpeg|gif';
			$config['max_size'] = '2048';
			$config['max_width'] = '1000';
			$config['max_height'] = '1000';

			$this->load->library('upload',$config);
			if (!$this->upload->do_upload()){
				$error = array('error' => $this->upload->display_errors());
				$upload_image = 'noimage.jpg';
			}
			else
			{
				$data = array('upload_data' => $this->upload->data());
				$upload_image = $_FILES['userfile']['name'];

			}

		$result = $this->m->add_Product($upload_image);
		$msg['success'] = false;	
		$msg['type'] = 'add';
		if($result){
			$msg['success'] = true;
		}
		echo json_encode($msg);
	}
		
		public function deleteProduct(){
		$result = $this->m->delete_Product();
		$msg['success'] = false;
		if($result){
			$msg['success'] = true;
			$msg['data']= $result['data'];
		}
		echo json_encode($msg);
	}


		public function deleteCart(){
		$result = $this->m->delete_Cart();
		$msg['success'] = false;
		if($result){
			$msg['success'] = true;
		}
		echo json_encode($msg);
	}




	public function editProduct(){
		$result = $this->m->edit_Product();{

			echo json_encode($result);
		}
	}




	function ajax_upload()
	{
		if(isset($_FILES["image_file"]["name"]))
		{
			
			$config['upload_path']='./assets/image/upload';

			$config['allowed_types'] = 'jpg|jpeg|png|gif';
			$this->load->library('upload', $config);
			if(!$this->upload->do_upload('image_file'))
			{
			$error = array('error' => $this->upload->display_errors());
				$upload_image = 'noimage.jpg';
			}
			else
			{
				$data = array('upload_data' => $this->upload->data());
				$upload_image = $_FILES['image_file']['name'];
			}
				$result = $this->m->add_Product($upload_image);
			$msg['success'] = false;	
			$msg['type'] = 'add';
			if($result['status']){
			$msg['success'] = true;
			$msg['data']= $result['data'];
		}
		echo json_encode($msg);
		}
	}


	public function updateProduct(){
		$result = $this->m->update_Product();
		$msg['success'] = false;
		$msg['type'] = 'update';
		if($result){
			$msg['success'] = true;
			$msg['data']= $result['data'];
		}
		echo json_encode($msg);
	}

}
