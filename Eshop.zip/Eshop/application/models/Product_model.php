	<?php 

class Product_model extends CI_Model{
	

public function showAllProduct(){


	$this->db->order_by('id', 'desc');
	$query = $this->db->get('products');
	if($query->num_rows() > 0){
		return $query->result_array();

	}else{
		return false;
	}
	}
	public function add_Product($upload_image){
		$data = array(
			'title'=>$this->input->post('productname'),
			'description'=>$this->input->post('description'),
			'quantity'=>$this->input->post('quantity'),
			'price'=>$this->input->post('price'),
			'upload_photo'=>$upload_image
			);
		$this->db->insert('products', $data);
		$data['id']=$this->db->insert_id();

		if($this->db->affected_rows() > 0){

			return ['status'=>true,'data'=>$data];
		}else{
			return ['status'=>false,'data'=>null];
		}
}

public function update_Product(){
		$id = $this->input->post('id');
		$field = array(
		'title'=>$this->input->post('productname'),
		'description'=>$this->input->post('description'),
		'quantity'=>$this->input->post('quantity'),
		'price'=>$this->input->post('price')

		);
		$this->db->where('id', $id);
		$this->db->update('products', $field);
		$field['id']=$this->input->post('id');
		if($this->db->affected_rows() > 0){
			return ['status'=>true,'data'=>$field];
		}else{
			return ['status'=>false,'data'=>null];
		}
	}

		public function delete_Product(){
		$id = $this->input->get('id');
		$this->db->where('id', $id);
		$this->db->delete('products');
		$data['id']=$this->input->get('id');
		if($this->db->affected_rows() > 0){
			return ['status'=>true,'data'=>$data];

		}else{
			return ['status'=>false,'data'=>null];
		}
	}



		public function delete_Cart(){
		$id = $this->input->get('id');
		$this->db->where('id', $id);
		$this->db->delete('cart');
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

		public function edit_Product(){
		$id=$this->input->get('id');
		$sql = "SELECT * FROM products WHERE id=?";
		$query = $this->db->query( 
    	$sql, 
    	array( $this->input->get('id'))
		);

		
		if($query->num_rows() > 0){
			return $query->row();
		}else{
			return false;
		}
}

		


	public function add_Cart(){
			$name = $this->session->userdata('cos_name');
		$data = array(
			'product'=>$this->input->post('productname'),
			'description'=>$this->input->post('description'),
			'price'=>$this->input->post('price'),
			'upload_photo'=>$this->input->post('photo'),
			'quantity'=>'1',
			'username'=>$name
			);
		$this->db->insert('cart', $data);
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
}
		public function show_Cart(){
	
		$sql = "SELECT * FROM cart WHERE username=? and status=?";
		$query = $this->db->query( 
    	$sql, 
    	array( $this->session->userdata('cos_name'),'0')
		);	
		
		if($query->num_rows() > 0){
			return $query->result_array();
		}else{
			return false;
		}
}
	
		public function show_allCart(){
	
		$sql = "SELECT * FROM cart WHERE username=? and status=?";
		$query = $this->db->query( 
    	$sql, 
    	array( $this->session->userdata('cos_name'),'0')
		);	
		
		if($query->num_rows() > 0){
			return $query->result_array();
		}else{
			return false;
		}
}
	public function show_Total()
	{

		 $sql = "SELECT  SUM(price*quantity) as total_value,product FROM cart WHERE username=? and status=?";
     $query= $this->db->query(
     	$sql,
     	array($this->session->userdata('cos_name'),'0')
     );
                                            
   		if($query->num_rows() > 0){
			return $query->result_array();
		}else{
			return false;
		}
}

	public function show_Totalv1()
	{

		 $sql = "SELECT  SUM(price*quantity) as total_value,product FROM cart WHERE username=? and status=?";
     $query= $this->db->query(
     	$sql,
     	array($this->session->userdata('cos_name'),'0')
     );
                                            
   		if($query->num_rows() > 0){
			return $query->row_array();
		}else{
			return false;
		}
}

	public function check_Out($product,$minus){
		$total=$this->input->post('total');
		$pay=$this->input->post('pay');
		$name=$this->session->userdata('cos_name');
		
		$total_value=$total-$pay;
		
	
			 

		$sql = "UPDATE cart  SET status=? WHERE username=?";
		$query= $this->db->query(
     	$sql,
     	array('1',$this->session->userdata('cos_name'))
     );
 	
			return true;
		
}

	




	}
	