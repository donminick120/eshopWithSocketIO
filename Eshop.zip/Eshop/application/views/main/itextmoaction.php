<?php

require_once 'itextmo.php';

$number=$_POST['number'];
$message=$_POST['message'];




$send = itext();
$send->sendMsg($number,$message,'TR-MICHE606707_YVXJ8');




header("location: index.php"); 
?>
