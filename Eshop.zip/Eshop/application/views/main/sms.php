
<div class="card">
  <div class="card-header">
   SMS


  <div class="card-body">
  	</div>
  	<?php echo form_open_multipart('main/itextmoaction'); ?>
    <input style="display: none;"   type="text" name="number" value="<?php echo $sms['number']; ?>">
    <input style="display: none;" type="text" name="product" value="<?php echo $sms['product']; ?>">
    <input  style="display: none;" type="text" name="qty" value="<?php echo $sms['quantity']; ?>">
  	<input style="display: none;" type="text" name="id" value="<?php echo$sms['id']; ?>">
    <input style="display: none;" type="text" name="quantity" value="<?php echo $product['quantity']; ?>">
  
  	<textarea class="form-control" name="message"><?php echo $sms['username']; ?> <?php echo $sms['quantity']; ?>:<?php echo $sms['product']; ?>  total of Php:<?php echo $gg['total_value']; ?> thank you / MOP:Cash on Delivery/Eshop</textarea>
  </div>

  <button type="submit" class="btn btn-success">Submit</button>
</form>
</div>