 <div id="table"  class="sidenav sidenav-expand-lg sidenav-white bg-primary" >
<h3>Your cart</h3>

<table   class="table table-striped table-bordered" >
<thead  style="background-color: white;"	>
	<h6>
	<td>Product</td>
	<td>Quantity</td>
	<td>Price</td>
	<td>action</td>



</thead>
<tbody id="showcart">

</tbody>

</table>
<button type="button" id="btnNext" class="btn btn-success" style="width: 100%;">Next</button>
</div>

								
<div id="showcartv2">
	
</div>								

<div id="showcartv1">

</div>





		 <?php if($this->session->flashdata('warning')){  ?>

			<div class="alert alert-warning">
			<a href="#" class="close" data-dismiss="alert">&times;</a>
			<strong>Warning!</strong> <?php echo $this->session->flashdata('warning'); } ?>


			   <?php if($this->session->flashdata('success')){  ?>

		<div class="alert alert-success">
			<a href="#" class="close" data-dismiss="alert">&times;</a>
			<strong>success!</strong> <?php echo $this->session->flashdata('success'); } ?>



		<h3>Products</h3>

		<?php foreach ($products as $products):
	

	endforeach;
		?>



<div id="deleteModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
  <div class="modal-content">
  <div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		<h4 class="modal-title">Confirm Delete</h4>
   </div>
	  <div class="modal-body">
			Do you want to remove?
   </div>
   <div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		<button type="button" id="btnDelete" class="btn btn-danger">Remove</button>
   </div>
   </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->



		<div class="alert alert-success" style="display: none;">
		
		</div>
<div id="addModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
	<div class="modal-content">
	  <div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		<h4 class="modal-title">Confirm Delete</h4>
	  </div>
	  <div class="modal-body">
			Do you want to add this <label id="forText"></label> to your Cart?
			<form id="editform" action="" method="post" class="form-horizontal">
				
				<input style="display: none;" type="text" name="productname">
				<textarea style="display: none;" type="text" name="description"></textarea> 
				<input style="display: none;" type="text" name="price">
				<input style="display: none;"  type="text" name="photo">


				<?php echo $this->input->get('productname'); ?>

			


	  </div>
	  <div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		<button type="button" id="btnAdd" class="btn btn-danger">Add</button>
	</form>
	  </div>
		</div><!-- /.modal-content -->
  	</div><!-- /.modal-dialog -->
		</div><!-- /.modal -->



			


	<div id="continuemodal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
  <div class="modal-content">
  <div class="modal-header">
	
		<h4 class="modal-title"></h4>
   </div>
	  <div class="modal-body">
			<form method="post" id="upload_form" align="center" enctype="multipart/form-data">
				<label id="forText"></label>
				<input style="display: none;" class="form-control" type="text" id="total" name="total">
				<h3>PAY</h3>
					<input class="form-control" type="text"  name="pay" id="pay">
					
					<div id="allcart"></div>
					
			
   </div>
   <div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	<input type="submit" name="upload" id="upload" value="Check Out" class="btn btn-info" />

	</form>
  </div>
  </div><!-- /.modal-content -->
 	</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->

 


	<div id="show" >
	

		</div>

		<div id="showdata" >
	

		</div>





		<script>
		 var socket = io.connect('http://localhost:3000');
     $(document).ready(function(){

   		 socket.on('refresh feed',function(data){

            $("#show").append('<div  class="gallery" style="width: 180px;height: 300px;">'+
            	'<p>'  +data.data1+'</p>'+
            	' <a href="<?php echo base_url()?>products/'+data.data6+'">' +
            	'<img src="<?php echo base_url(); ?>assets/image/upload/' +  data.data5+  '">'+
            	'</a>'+
            	'<p>Price :'+data.data4+'</p><br/>'+
            	'<td>'+
							'<a href="javascript:;" class="btn btn-info item-edit" data="'+data.data6+'">Add To Cart</a>'+
							'</td>'+
            	'</div>');
      

    });

   		 socket.on('deleted',function(data){
   		 	$('#showdata').find('#item-id'+data.data1+'').delay(1000).fadeOut('slow');



   		 });
			socket.on('update',function(data){
				
			$('#showdata').find('#item-title'+data.data6+'').text(''+data.data1+'');
			$('#showdata').find('#item-price'+data.data6+'').text('Price:'+data.data4+'');
			$('#showdata').find('#item-description'+data.data6+'').text(''+data.data2+'');

			 	 
			
      });

		});
	







	$(function(){
		showcart();
	$(function(){
		showAllProduct();
			

		$('#showcartv1').on('click', '.btn-continue', function(){
		
			$('#continuemodal').modal('show');
			$('#continuemodal').find('.modal-title').text('Check Out');;
			
			
		$.ajax({
				type: 'ajax',
				method: 'get',
				url: '<?php echo base_url() ?>Product/showTotalv1',
				async: false,
				dataType: 'json',
				success: function(data){
				
					$('#total').val(data.total_value);
					
				
						
				},
				error: function(){
					alert('Could not add product');
				}
			});
	
	$(function(){
		showallCart();	
		function showallCart(){
			$.ajax({
				type: 'ajax',
				url: '<?php echo base_url()?>product/showallCart',
				async: false,
				dataType: 'json',
				success: function(data){

					var html = '';
					var i;
					for(i=0; i<data.length; i++){
								html +='<td>'+
								'<input  style="display:none;" type="text" name="product[]" value="' +data[i].product+ '">'+
								'<input style="display:none;" type="text" name="minus[]" value="1">'+
								'</td>';
					
					}
					$('#allcart').html(html);
					},
					 error: function(){
					alert('Could not get Data from Database');
				}
			});
		}


});


		$(document).ready(function(){
		$('#upload_form').on('submit', function(e){
		e.preventDefault();  
		var total = document.getElementById('total');
		var pay = document.getElementById('pay');
		var totalv1 = parseFloat(total.value)||0;
		var payv1 = parseFloat(pay.value)||0;
		if(totalv1 > payv1)

		{
			alert("Your Money is Less than the Total");
		} 
		else if(totalv1 == "")
		{
			alert("Please Add Something to your Cart");
		}		
		else
		{
			$.ajax({
				url:"<?php echo base_url(); ?>product/checkOut", 
					method:"POST",
				data:new FormData(this),
				contentType: false,
				cache: false,
				processData:false,
				success:function(data)
				{
					
				$('#continuemodal').modal('hide');
				$('.alert-success').html('Checkout successfully').fadeIn().delay(4000).fadeOut('slow');
				$("#tablev1").hide();
						showcart();
						$("#table").show();
							$('#editform')[0].reset();
				}
			});
			}
			});
			})	

		});



		$('#showcartv1').on('click', '.item-cancel', function(){	
		{
		$("#tablev1").hide();
		$("#table").show();

		}
		})
						


		$('#showcart').on('click', '.item-delete', function(){
			var id = $(this).attr('data');
			$('#deleteModal').modal('show');
			$('#btnDelete').unbind().click(function(){
				$.ajax({
					type: 'ajax',
					method: 'get',
					async: false,
					url: '<?php echo base_url() ?>product/deleteCart',
					data:{id:id},
					dataType: 'json',
					success: function(response){
						if(response.success){
							$('#deleteModal').modal('hide');

							$('.alert-success').html('Product Remove successfully').fadeIn().delay(4000).fadeOut('slow');
							showcart();


						}else{
							alert('Error');
						}
					},
					error: function(){
						alert('Error deleting');
					}
				});
			});
		});





		$('#btnNext').click(function(){
		{	
		$("#table").hide();

		$.ajax({
				type: 'ajax',
				url: '<?php echo base_url()?>product/showTotal',
				async: false,
				dataType: 'json',
				success: function(data){

					var html = '';
					var i;

					for(i=0; i<data.length; i++){
								html +='<div id="tablev1"  class="sidenav sidenav-expand-lg sidenav-white bg-primary" >'+
								'<h2>Your billing</h2>'+
								'<h4>'+'Total ---------'+data[i].total_value+'</h4><br/>'+
								'<a href="javascript:;" class="btn btn-success btn-continue" data="'+data[i].id+'">Continue</a><a href="javascript:;" class="btn btn-danger item-cancel" data="'+data[i].id+'">Cancel</a>'+

								
								'</div>';
					
					}
					$('#showcartv1').html(html);
					},
					 error: function(){
					alert('Could not get Data from Database');
				}
			});
	


		}});





					$('#btnAdd').click(function(){
					$('#addModal').find('.modal-title').text('Edit Product');
					$('#editform').attr('action', '<?php echo base_url() ?>product/addCart');
				});


		$('#btnAdd').click(function(){
			var url = $('#editform').attr('action');
			var data = $('#editform').serialize();
			//validate form
			var productname = $('input[name=productname]');
			var description = $('textarea[name=description]');
			var result = '';
			if(productname.val()==''){
				productname.parent().parent().addClass('has-error');
			}else{
				productname.parent().parent().removeClass('has-error');
				result +='1';
			}
			if(description.val()==''){
				description.parent().parent().addClass('has-error');
			}else{
				description.parent().parent().removeClass('has-error');
				result +='2';
			}

			if(result=='12'){
				$.ajax({
					type: 'ajax',
					method: 'post',
					url: url,
					data: data,
					async: false,
					dataType: 'json',
					success: function(response){
						if(response.success){
							$('#addModal').modal('hide');
							$('#editform')[0].reset();
							if(response.type=='add'){
								var type = 'added'
							}else if(response.type=='update'){
								var type ="added to cart"
							}
							$('.alert-success').html('Product '+type+' successfully').fadeIn().delay(4000).fadeOut('slow');
							
							showcart();
							showAllProduct();

						}else{
							alert('Error');
						}
					},
					error: function(){
						alert('Could not add data');
					}
				});
			}
		});
	


			$('#showdata').on('click', '.item-edit', function(){
			var id = $(this).attr('data');
			$('#addModal').modal('show');
			$('#addModal').find('.modal-title').text('Add Cart Product');;
			
			
		$.ajax({
				type: 'ajax',
				method: 'get',
				url: '<?php echo base_url() ?>product/editProduct',
				data: {id: id},
				async: false,
				dataType: 'json',
				success: function(data){
					$('#forText').text(data.title);
					$('input[name=productname]').val(data.title);
					$('textarea[name=description]').val(data.description);
					$('input[name=quantity]').val(data.quantity);
					$('input[name=price]').val(data.price);
					$('input[name=photo]').val(data.upload_photo);
						
				},
				error: function(){
					alert('Could not add product');
				}
			});
		})	
		});

		function showAllProduct(){
			$.ajax({
				type: 'ajax',
				url: '<?php echo base_url()?>product/showAllProduct',
				async: false,
				dataType: 'json',
				success: function(data){
					var html = '';
					var i;
				 
					for(i=0; i<data.length; i++){

					   
						html +='<div id="item-id'+data[i].id+'" class="gallery" style="width: 180px;height: 300px;">'+
								'<p id="item-title'+data[i].id+'">'  +data[i].title+'</p>'+
								
								' <a href="<?php echo base_url()?>products/'+data[i].id+'">' +'<img src="<?php echo base_url(); ?>assets/image/upload/' +   data[i].upload_photo+  '">'+'</a>'+
								'<p id="item-description'+data[i].id+'">'+data[i].description+'</p>'+
								'<p id="item-price'+data[i].id+'">Price :'+data[i].price+'</p><br/>'+  
								'<td>'+
										
								'<a href="javascript:;" class="btn btn-info item-edit" data="'+data[i].id+'">Add To Cart</a>'+
								'</td>'+
								'</div>';
					}
					$('#showdata').html(html);
					},
					 error: function(){
					alert('Could not get Data from Database');
				}
			});
		}


			function showcart(){
			$.ajax({
				type: 'ajax',
				url: '<?php echo base_url()?>product/showCart',
				async: false,
				dataType: 'json',
				success: function(data){

					var html = '';
					var i;
					for(i=0; i<data.length; i++){
								html +='<tr>'+
								'<td>'  +data[i].product+'</td>'+
								'<td>'  +data[i].quantity+'</td>'+
								'<td>'  +data[i].price+'</td>'+
								'<td>'+'<a href="javascript:;" class="btn btn-danger item-delete" data="'+data[i].id+'">X</a>'+'</td>' 
								'</tr>';
					
					}
					$('#showcart').html(html);
					},
					 error: function(){
					alert('Could not get Data from Database');
				}
			});
		}

		})




		</script>	