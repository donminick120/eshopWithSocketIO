





<?php if($this->session->flashdata('warning')){  ?>

        <div class="alert alert-warning">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong>Warning!</strong> <?php echo $this->session->flashdata('warning'); } ?>


               <?php if($this->session->flashdata('success')){  ?>

        <div class="alert alert-success">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong>success!</strong> <?php echo $this->session->flashdata('success'); } ?>

<table class="table table-striped table-bordered" style="width: 1100px;" align="right"  >

  <tr>
  <td>ID</td>
  <td>Product</td>
  <td>Total Income</td>
  <td>Costumer</td>
  <td>Date</td>
  <td>Action</td>
  </tr>

  <tr>
 <?php foreach ($sale as  $row) : ?>
   
<td><?php echo $row['id']; ?></td>
<td><?php echo $row['product']; ?></td>
<td><?php echo $row['price']; ?></td>
<td><?php  echo $row['username']; ?></td>
<td><?php echo $row['date']; ?></td>
 <td style="display: none;"><?php echo form_open('/main/getsms/'.$row['id']); ?></td>
<td style="display: none;" ><input type="text" name="product" value="<?php echo $row['product']; ?>"></td>
<td><input type="submit" name="submit" class="btn btn-success" value="Approved"></form>

 <input type="submit" name="submit" class="btn btn-danger" value="Declined"></td>


</tr>
 <?php endforeach; ?> 
 </table>