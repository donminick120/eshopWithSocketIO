







<table class="table table-striped table-bordered" style="width: 1100px;" align="right"  >

  <tr>
  <td>ID</td>
  <td>Product</td>
  <td>Price</td>
  <td>Costumer</td>
  <td>Quatity</td>
  <td>Date</td>
  
  </tr>

  <tr>
 <?php foreach ($sale as  $row) : ?>
   
<td><?php echo $row['id']; ?></td>
<td><?php echo $row['product']; ?></td>
<td><?php echo $row['price']; ?></td>
<td><?php  echo $row['username']; ?></td>
<td><?php  echo $row['quantity']; ?></td>
<td><?php echo $row['date']; ?></td>


</tr>
 <?php endforeach; ?> 

<td></td>
 <td></td>
 <td><b>Total Income</b>  Php : <?php echo $total['total_value']; ?></td>
 <td></td>
 <td></td> 
 <td></td>
</table>