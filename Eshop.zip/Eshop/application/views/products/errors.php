


	$('#btnSave').click(function(){
			var url = $('#myForm').attr('action');
			var data = $('#myForm').serialize();
			//validate form
			var productname = $('input[name=productame]');
			var description = $('textarea[name=description]');
			var quantity = $('input[name=quantity]');
			var price = $('input[name=prince]');
			var photo = $('input[name=userfile]');
		
			var result = '';
			if(productname.val()==''){
				productname.parent().parent().addClass('has-error');
			}else{	
				productname.parent().parent().removeClass('has-error');
				result +='1';
			}
			if(description.val()==''){
				description.parent().parent().addClass('has-error');
			}else{
				description.parent().parent().removeClass('has-error');
				result +='2';
			}
			if(quantity.val()==''){
				quantity.parent().parent().addClass('has-error');
			}else{
				quantity.parent().parent().removeClass('has-error');
				result +='3';
			}
			if(price.val()==''){
				price.parent().parent().addClass('has-error');
			}else{
				price.parent().parent().removeClass('has-error');
				result +='4';
			
			}
			if(photo.val()==''){
				photo.parent().parent().removeClass('has-error');
			}else{
				photo.parent().parent().removeClass('has-error');
				result+='5';
			}
			if(result=='12345'){
				$.ajax({
					type: 'ajax',
					method: 'post',
					url: url,
					data: data,
					async: false,
					dataType: 'json',
					success: function(response){
						if(response.success){
							$('#myModal').modal('hide');
							$('#myForm')[0].reset();
							if(response.type=='add'){
								var type = 'added'
							}else if(response.type=='update'){
								var type ="updated"
							}
							$('.alert-success').html('products'+type+' successfully').fadeIn().delay(4000).fadeOut('slow');
							showAllProduct();
						}else{
							alert('Error');
						}
					},
					error: function(){
						alert('Could not add data');
					}
				});
			}
		});
