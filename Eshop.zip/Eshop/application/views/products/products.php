

<div class="container">
	<h3>Product Lists</h3>
	<div class="alert alert-success" style="display: none;">
		
	</div>
		<button id="btnAdd" class="btn btn-success">Add New</button>


<table class="table table-striped table-bordered" style="width: 900px;"  >
		<thead>
			<tr>
				<td>image</td>
				<td>Title</td>
				<td>Description</td>
			
				<td>Price</td>
				<td>Action</td>
			</tr>
		</thead>
		<tbody id="showdata">
			
				
	
		</tbody>
	</table>
</div>

		<div id="myModal" class="modal fade" tabindex="-1" role="dialog">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Modal title</h4>
			  </div>
			  <div class="modal-body">
				
					<form id="myForm" action="" method="post" class="form-horizontal"  enctype="multipart/form-data" >
						<input type="hidden" name="id" value="0">
						<div class="form-group">
							<label for="productnames" class="label-control col-md-4">Product Name</label>
							<div class="col-md-8">
								<input type="text" id="productname" name="productname" class="form-control">
							</div>
						</div>
						<div class="form-group">
							<label for="description" class="label-control col-md-4">Description</label>
							<div class="col-md-8">
								<textarea class="form-control" id="description" name="description"></textarea>
							</div>
						</div>
						
							<div class="form-group">
							<label for="quantity" class="label-control col-md-4">Quantity</label>
							<div class="col-md-8">
								<input type="number" id="quantity" name="quantity" class="form-control">
							</div>
						</div>
							<div class="form-group">
							<label for="Price" class="label-control col-md-4">Price Name</label>
							<div class="col-md-8">
								<input type="number" id="price" name="price" class="form-control">
							</div>
						</div>
							<div class="form-group">
							<label for="user_file" class="label-control col-md-4">Upload Photo</label>
							<div class="col-md-8">
								 <input type="file" name="image_file" id="image_file" />
							</div>
						</div>
					
			  </div>
			  <div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="submit" id="btnSave" class="btn btn-primary">Save</button>
			   
				</form>
			  </div>
			</div><!-- /.modal-content -->
		  </div><!-- /.modal-dialog -->
		</div><!-- /.modal -->




<!--edit-->
		<div id="editModal" class="modal fade" tabindex="-1" role="dialog">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Modal title</h4>
			  </div>
			  <div class="modal-body">
				
					<form id="editform" action="" method="post" class="form-horizontal">
						<input type="hidden" name="id" value="0">
						<div class="form-group">
							<label for="productnames" class="label-control col-md-4">Product Name</label>
							<div class="col-md-8">
								<input type="text" id="productname" name="productname" class="form-control">
							</div>
						</div>
						<div class="form-group">
							<label for="description" class="label-control col-md-4">Description</label>
							<div class="col-md-8">
								<textarea class="form-control" id="description" name="description"></textarea>
							</div>
						</div>
						
							<div class="form-group">
							<label for="quantity" class="label-control col-md-4">Quantity</label>
							<div class="col-md-8">
								<input type="number" id="quantity" name="quantity" class="form-control">
							</div>
						</div>
							<div class="form-group">
							<label for="Price" class="label-control col-md-4">Price Name</label>
							<div class="col-md-8">
								<input type="number" id="price" name="price" class="form-control">
							</div>
						</div>
							<div class="form-group">
							<label for="user_file" class="label-control col-md-4">Upload Photo</label>
							<div class="col-md-8">
								 <input type="file" name="image_file" id="image_file" />
							</div>
						</div>
					
			  </div>
			  <div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="button" id="btnedit" class="btn btn-primary">Save changes</button>
			   
				</form>
			  </div>
			</div><!-- /.modal-content -->
		  </div><!-- /.modal-dialog -->
		</div><!-- /.modal -->


<div id="deleteModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
	<div class="modal-content">
	  <div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		<h4 class="modal-title">Confirm Delete</h4>
	  </div>
	  <div class="modal-body">
			Do you want to delete this record?
	  </div>
	  <div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		<button type="button" id="btnDelete" class="btn btn-danger">Delete</button>
	  </div>
	</div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<div id="deleteModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
  <div class="modal-content">
  <div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		<h4 class="modal-title">Confirm Delete</h4>
   </div>
	  <div class="modal-body">
			Do you want to delete this record?
   </div>
   <div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		<button type="button" id="btnDelete" class="btn btn-danger">Delete</button>
   </div>
   </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->






<script>

  var socket = io.connect('http://localhost:3000')

    /*     $(document).ready(function(){
          // var socket = io();
       	 $("#btnSave").click(function(){
            socket.emit('product added',{data1: $("#productname").val(), data2:$("#description").val(), data3:$("#quantity").val(),data4:$("#price").val(),data5:$("#image_file").val()});
          	
     
	          });
        
});*/



	$(function(){
		showAllProduct();

			$('#btnAdd').click(function(){
					$('#myModal').modal('show');
					$('#myModal').find('.modal-title').text('Add Product');
				$.ajax({
				type: 'ajax',
				method: 'get',
				url: '<?php echo base_url() ?>product/editProduct',
				data: {id: id},
				async: false,
				dataType: 'json',
				success: function(data){
					$('input[name=id]').val(data.id);
					$('input[name=productname]').val(data.title);
					$('textarea[name=description]').val(data.description);
					$('input[name=quantity]').val(data.quantity);
					$('input[name=price]').val(data.price);
				},
				error: function(){
					alert('Could not Edit Data');
				}
			});
				});



			$(document).ready(function(){
		$('#myForm').on('submit', function(e){
		e.preventDefault();
		if($('#image_file').val() == '' )
		{
			alert("Please Select the File");
		}
		else if($('#productname').val() == '' ){
			alert("Please Enter Productname");
		}
		else if($('#description').val() == '' ){
			alert("Please Enter description");
		}
		else if($('#quantity').val() == '' ){
			alert("Please Enter quantity");
		}
		else if($('#price').val() == '' ){
			alert("Please Enter price");
		}
		else
		{
			$.ajax({
				url:"<?php echo base_url(); ?>product/ajax_upload", 
				method:"POST",
				data:new FormData(this),
				contentType: false,
				cache: false,
				processData:false,
				async: false,
				dataType: 'json',
				success: function(response){
					console.log(response)
						if(response.success){
							 socket.emit('product added',{data1: $("#productname").val(), data2:$("#description").val(), data3:$("#quantity").val(),data4:$("#price").val(),data5:response.data.upload_photo,data6:response.data.id});
							$('#myModal').modal('hide');
							$('#myForm')[0].reset();
							if(response.type=='add'){
								var type = 'added'
							}else if(response.type=='update'){
								var type ="updated"
								socket.emit('product_update',{data1: $("#productname").val(), data2:$("#description").val(), data3:$("#quantity").val(),data4:$("#price").val(),data5:response.data.upload_photo,data6:response.data.id});
							}
							$('.alert-success').html('products'+type+' successfully').fadeIn().delay(4000).fadeOut('slow');
							showAllProduct();
						}else{
							alert('Error');
						}
					},
					error: function(){
						alert('Could not add data');
					}
			});
		}
	});
});



	$(function(){
		showAllProduct();

			$('#btnedit').click(function(){
					$('#editModal').modal('show');
					$('#editModal').find('.modal-title').text('Edit Product');
					$('#editform').attr('action', '<?php echo base_url() ?>product/updateProduct');
				});


		$('#btnedit').click(function(){
			var url = $('#editform').attr('action');
			var data = $('#editform').serialize();
			//validate form
			var productname = $('input[name=productname]');
			var description = $('textarea[name=description]');
			var result = '';
			if(productname.val()==''){
				productname.parent().parent().addClass('has-error');
			}else{
				productname.parent().parent().removeClass('has-error');
				result +='1';
			}
			if(description.val()==''){
				description.parent().parent().addClass('has-error');
			}else{
				description.parent().parent().removeClass('has-error');
				result +='2';
			}

			if(result=='12'){
				$.ajax({
					type: 'ajax',
					method: 'post',
					url: url,
					data: data,
					async: false,
					dataType: 'json',
					success: function(response){
						if(response.success){
							$('#editModal').modal('hide');
							$('#editform')[0].reset();
							if(response.type=='add'){
								var type = 'added'
							}else if(response.type=='update'){
								var type ="updated"
							 socket.emit('product_update',{data1:response.data.title, data2:response.data.description, data3:response.data.quantity,data4:response.data.price,data5:response.data.upload_photo,data6:response.data.id});
							}
							$('.alert-success').html('Product '+type+' successfully').fadeIn().delay(4000).fadeOut('slow');
							showAllProduct();
						}else{
							alert('Error');
						}
					},
					error: function(){
						alert('Could not add data');
					}
				});
			}
		});
	})

	
		$('#showdata').on('click', '.item-edit', function(){
			var id = $(this).attr('data');
			$('#editModal').modal('show');
			$('#editModal').find('.modal-title').text('Edit Product');
			$('#editModal').attr('action', '<?php echo base_url() ?>product/updateProduct');
			$.ajax({
				type: 'ajax',
				method: 'get',
				url: '<?php echo base_url() ?>product/editProduct',
				data: {id: id},
				async: false,
				dataType: 'json',
				success: function(data){
					$('input[name=id]').val(data.id);
					$('input[name=productname]').val(data.title);
					$('textarea[name=description]').val(data.description);
					$('input[name=quantity]').val(data.quantity);
					$('input[name=price]').val(data.price);
				},
				error: function(){
					alert('Could not Edit Data');
				}
			});
		});



	//delete- 
		$('#showdata').on('click', '.item-delete', function(){
			var id = $(this).attr('data');
			$('#deleteModal').modal('show');
			//prevent previous handler - unbind()
			$('#btnDelete').unbind().click(function(){
				$.ajax({
					type: 'ajax',
					method: 'get',
					async: false,
					url: '<?php echo base_url() ?>product/deleteproduct',
					data:{id:id},
					dataType: 'json',
					success: function(response){
						if(response.success){
							$('#deleteModal').modal('hide');
							socket.emit('request',{data1:response.data.id});
							$('.alert-success').html('Product Deleted successfully').fadeIn().delay(4000).fadeOut('slow');
							showAllProduct();
						}else{
							alert('Error');
						}
					},
					error: function(){
						alert('Error deleting');
					}
				});
			});
		});


		function showAllProduct(){
			$.ajax({
				type: 'ajax',
				url: '<?php echo base_url()?>product/showAllProduct',
				async: false,
				dataType: 'json',
				success: function(data){
					var html = '';
					var i;
					for(i=0; i<data.length; i++){
						html +='<tr>'+
						
								'<td>'	+'<img src="<?php echo base_url(); ?>assets/image/upload/' +data[i].upload_photo+  '">'+'</td>'+
									'<td>'+data[i].title+'</td>'+ 
								 
									'<td>'+data[i].quantity+'</td>'+
									'<td>'+data[i].price+'</td>'+
									'<td>'+
										'<a href="javascript:;" class="btn btn-info item-edit" data="'+data[i].id+'">Edit</a>'+
										'<a href="javascript:;" class="btn btn-danger item-delete" data="'+data[i].id+'">Delete</a>'+
									'</td>'+
								'</tr>';
					}
					$('#showdata').html(html);
				},
				error: function(){
					alert('Could not get Data from Database');
				}
			});
		}
	
});
</script>