


  <style >
  img{
    width: 100px;
    height: 8   0px;
  }
    .form-int{
      width: 200px;


    }
    .gg{
      width: 800px;
      height: 500px;
    }
  div.gallery {
    margin: 5px;
    border: 1px solid #ccc;
    float: left;
    width: 180px;
  }

  div.gallery:hover {
    border: 1px solid #777;
  }

  div.gallery img {
    width: 100%;
    height: auto;
  }

  div.desc {
    padding: 15px;
    text-align: center;
  }

  .card {
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
    max-width: 900px;
    margin: auto;
    text-align: center;
    font-family: arial;
  }

  .price {
    color: grey;
    font-size: 22px;
  }

  .card button {
    border: none;
    outline: 0;
    padding: 12px;
    color: white;
    background-color: #000;
    text-align: center;
    cursor: pointer;
    width: 100%;
    font-size: 18px;
  }

  .card button:hover {
    opacity: 0.7;
  }


  </style>
  <!DOCTYPE html>
  <html>
  <head>


    <title>Eshop</title>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/2.2.0/socket.io.js"></script>
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-3.1.1.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> 
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-3.1.1.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

  
  </head>
  <body style="margin-top: 0px;">
    <nav  class="navbar navbar-expand-lg navbar-dark bg-primary">




    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse" id="navbarColor01">
      <ul class="nav navbar-nav navbar-left" >
        <li class="nav-item active"> 
            <a class="nav-link"><?php echo "<h6> ".$this->session->userdata('admin_name').'</h6>' ; ?></a>  
        </li>
        <li class="nav-item active">

    <a style="color:black;" class="nav-link">Eshop</a>
        
        </li>
      
         <li style="text-decoration-color: black" >
        <a style="color:black;" class="nav-link" href="<?php echo base_url(); ?>allproduct">Products</a>
        </li>
        <li >
         <a style="color:black;" class="nav-link" href="<?php echo base_url(); ?>categories">Categories</a>
        </li>
        <li >
          <a style="color:black;" class="nav-link" href="<?php echo base_url(); ?>order">Order</a>
        </li>
        <li >
        <a style="color:black;" class="nav-link" href="<?php echo base_url(); ?>sale">Sales</a>
        </li>

        <!-- <li class="nav-item">
          <a class="nav-link" href="#">Logo</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">About</a>
        </li>-->
      </ul>
      <ul class="nav navbar-nav navbar-right">

    <li><a style="color:black;" class="nav-link" href="<?php echo base_url(); ?>addcategory">Add Category</a></li>
        <li><a style="color:black;" class="nav-link" href="<?php echo base_url(); ?>createpostv1">Add Product</a></li>
        <li><a style="color:black;" class="nav-link" href="<?php echo base_url(); ?>admin_logout">Log out</a>
        
        
      </ul>
      
    </div>
  </nav>
  </body>
  <div style="margin-top: 80px;width: 800px;height: 500px;" class="container">
  </html>