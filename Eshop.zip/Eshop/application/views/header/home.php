<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.4.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/2.2.0/socket.io.js"></script>


<div class="container">
<h3>Product</h3>
<table  class="table table-striped table-bordered">
<thead>
<td>product</td>
<td>quantity</td>	
</thead>	
</table>	

</div>

<script>
	$(function(){
		var	socket = io.connect();
		var $addproductform = $('#messageForm');



	})	



</script>