<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Test</title>
</head>
<body>
<h1>Hello</h1>
<?php echo "taph"; ?>
</body>

</html>