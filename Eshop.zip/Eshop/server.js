var app     =     require("express")();
var mysql   =     require("mysql");
var http    =     require('http').Server(app);
var io      =     require("socket.io")(http);
  
/* Creating POOL MySQL connection.*/

/*var pool    =    mysql.createPool({
      connectionLimit   :   100,
      host              :   'localhost',
      user              :   'root',
      password          :   '',
      database          :   'try',
      debug             :   false
});*/

// app.get("/",function(req,res){
//     res.sendFile(__dirname + '/index.html');
// });



io.on('connection',function(socket){  
    
  socket.on('product added', function(data){
    io.emit('refresh feed',data)
  
        
   
    });
});


io.on('connection',function(socket){  
    
    socket.on('request', function(data){
      io.emit('deleted',data)
    
        
   
    });
});

io.on('connection',function(socket){  
    
  socket.on('product_update', function(data){
    io.emit('update',data)
  
        
   
    });
});

http.listen(3000,function(){
    console.log("Listening on 3000");
});
