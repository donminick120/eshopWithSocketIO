-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2019 at 05:17 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `billing`
--

CREATE TABLE IF NOT EXISTS `billing` (
  `id` int(11) NOT NULL,
  `session` varchar(255) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `card_name` varchar(255) NOT NULL,
  `credit_card` varchar(255) NOT NULL,
  `exp_month` varchar(255) NOT NULL,
  `exp_year` varchar(255) NOT NULL,
  `cvv` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `billing`
--

INSERT INTO `billing` (`id`, `session`, `fullname`, `email`, `address`, `city`, `state`, `zipcode`, `card_name`, `credit_card`, `exp_month`, `exp_year`, `cvv`) VALUES
(3, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', 'donminick', '1112-3212-2232', 'september', '1999', '232'),
(4, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231', '1313', 'september', '1999', '231'),
(5, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231', '1313', 'september', '1999', '231'),
(6, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231', '1313', 'september', '1999', '231'),
(7, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231', '1313', 'september', '1999', '231'),
(8, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', 'donminick', '123', '131', '1231', '1311'),
(9, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '213', '231', '1313', '1231', '313'),
(10, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', 'donminicl', '123', '232', '3', '13'),
(11, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', 'donminick', '123-23123-21313', 'september', '209', '12i'),
(12, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123', '2313-231-1231', 'september', '2019', '200'),
(13, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '213131', '131', '1231', '13', '31'),
(14, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', 'donmiick', '2313-12331-12313', 'september', '123', '2131'),
(15, 'donminick', 'do', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '2131', '12313', '131', '132', '123'),
(16, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '12313', 'ewf1231', 'd1231', 'q2312', '1313'),
(17, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '12313', '21321', '13', '123', '1231'),
(18, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', 'donminick', '123-1231-1233', 'september', '1999', '332'),
(19, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '221', '123', '123', '123', '123'),
(20, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '221', '123', '123', '123', '123'),
(21, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '221', '123', '123', '123', '123'),
(22, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '221', '123', '123', '123', '123'),
(23, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '221', '123', '123', '123', '123'),
(24, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '221', '123', '123', '123', '123'),
(25, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '221', '123', '123', '123', '123'),
(26, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '23131', '1231', '1313', '1311231', '2131'),
(27, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231', '1231', '1232131', '123', '123'),
(28, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231', '1231', '1232131', '123', '123'),
(29, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '2131', '131', '3213131', '31', '31'),
(30, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231-123', '1231', '2131', '31', '1231'),
(31, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231-124', '123-231--45-', '21231', '131-123', '3131'),
(32, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231-1231', '1231-123131', '1231-', '213131', '13131'),
(33, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231-1231', '1231-123131', '1231-', '213131', '13131'),
(34, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231-1231', '1231-123131', '1231-', '213131', '13131'),
(35, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231-1231', '1231-123131', '1231-', '213131', '13131'),
(36, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231-1231', '1231-123131', '1231-', '213131', '13131'),
(37, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231-1231', '1231-123131', '1231-', '213131', '13131'),
(38, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231-1231', '1231-123131', '1231-', '213131', '13131'),
(39, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231-1231', '1231-123131', '1231-', '213131', '13131'),
(40, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231-1231', '1231-123131', '1231-', '213131', '13131'),
(41, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231-1231', '1231-123131', '1231-', '213131', '13131'),
(42, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231-1231', '1231-123131', '1231-', '213131', '13131'),
(43, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231', '12321-', '23131', '3211', '231-'),
(44, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231', '12321-', '23131', '3211', '231-'),
(45, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-411', '123', '12311', '321', '31'),
(46, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123-1231-1231', '1231-123', '321', '312', '31'),
(47, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123-1231-1231', '1231-123', '321', '312', '31'),
(48, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123-1231-1231', '1231-123', '321', '312', '31'),
(49, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123-1231-1231', '1231-123', '321', '312', '31'),
(50, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123-1231-1231', '1231-123', '321', '312', '31'),
(51, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123-1231-1231', '1231-123', '321', '312', '31'),
(52, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123-1231-1231', '1231-123', '321', '312', '31'),
(53, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123-1231-1231', '1231-123', '321', '312', '31'),
(54, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123-1231-1231', '1231-123', '321', '312', '31'),
(55, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123-1231-1231', '1231-123', '321', '312', '31'),
(56, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123-1231-1231', '1231-123', '321', '312', '31'),
(57, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123-1231-1231', '1231-123', '321', '312', '31'),
(58, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123-1231-1231', '1231-123', '321', '312', '31'),
(59, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123-1231-1231', '1231-123', '321', '312', '31'),
(60, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123', '321', '31', '31', '321'),
(61, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123', '321', '31', '31', '321'),
(62, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231', '1231', '31', '32131', '231231'),
(63, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231', '1231', '31', '32131', '231231'),
(64, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231', '1231', '31', '32131', '231231'),
(65, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231', '1231', '31', '32131', '231231'),
(66, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231', '1231', '31', '32131', '231231'),
(67, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '1231-1231', '1231', '31', '32131', '231231'),
(68, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '2131-123', '321', '31', '31', '3123'),
(69, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123', '31', '31', '31', '3131'),
(70, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123-1231-123', '123-', '31-', '3113', '1231'),
(71, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '2131-21231-123-', '12321-123-131-', '13-', '31-', '31-'),
(72, 'allenjr', 'allen', 'allen@yahoo.com', 'brgy 8 tanga', 'batangas', 'ada', 'ada', 'asda', 'da', 'dsd', 'dssfs', 'sfs'),
(73, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123', '2131', '213', '131', '31231'),
(74, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123--123', '324', '2342', '24', '2424'),
(75, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123', '231', '31', '231', '321'),
(76, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '12331', '1231', '1313', '1231', '3131'),
(77, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '123', '13', '312', '313', '31'),
(78, 'lyewee', 'lyeweleen', 'lyewleen1232@yahoo.com', 'biga ', 'calatagan', 'ad', 'ada', 'ad13', '123123', '1321', 'w2321', '31321'),
(79, 'lyewee', 'lyeweleen', 'lyewleen1232@yahoo.com', 'biga', 'calatagan', 'ad', 'ada', '123', '321', '131', '3131313', '1231'),
(80, 'donminick', 'donminick P. Bautista', 'donminick120@gmail.com', 'cogunan', 'nasugbu', 'batangas', '4231', '12323', '31', '31', '31', '313'),
(81, 'lyewee', 'lyeweleen', 'lyewleen1232@yahoo.com', 'biga', 'calatagan', 'ad', 'ada', '123', '31', '31', '313', '31');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `product` varchar(255) NOT NULL,
  `description` varchar(1200) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `upload_photo` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=233 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `username`, `product`, `description`, `quantity`, `price`, `upload_photo`, `status`, `date`) VALUES
(167, 'donminick', 'pc1', 'wqeeqe', '1', '2133', 'px.png', 1, '2019-05-02 06:07:36'),
(168, 'donminick', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 1, '2019-05-02 08:44:29'),
(169, 'donminick', '7 Buttons LED', '<p>Optical Wireless Gaming Mouse For Win7/8 ME XP, 2400 DPI /1600 DPI /1000 DPI /600 DPI&nbsp;</p>\r\n', '1', '1900', 'mosuess.png', 1, '2019-05-02 08:44:31'),
(170, 'donminick', 'pc1', 'wqeeqe', '1', '2133', 'px.png', 1, '2019-05-02 08:46:42'),
(171, 'donminick', 'pc1', 'wqeeqe', '1', '2133', 'px.png', 1, '2019-05-02 10:34:22'),
(175, 'donminick', 'pc1', 'wqeeqe', '1', '2133', 'px.png', 1, '2019-05-02 11:10:32'),
(176, 'donminick', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 1, '2019-05-02 11:10:39'),
(177, 'donminick', 'pc1', 'wqeeqe', '1', '2133', 'px.png', 1, '2019-05-02 11:11:39'),
(178, 'donminick', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 1, '2019-05-02 11:11:41'),
(179, 'donminick', 'pc1', 'wqeeqe', '1', '2133', 'px.png', 1, '2019-05-02 11:12:14'),
(180, 'donminick', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 1, '2019-05-02 11:12:16'),
(181, 'donminick', 'pc1', 'wqeeqe', '1', '2133', 'px.png', 1, '2019-05-02 11:13:09'),
(182, 'donminick', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 1, '2019-05-02 11:13:11'),
(183, 'donminick', 'pc1', 'wqeeqe', '1', '2133', 'px.png', 1, '2019-05-02 11:15:10'),
(184, 'donminick', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 1, '2019-05-02 11:16:27'),
(185, 'donminick', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 1, '2019-05-02 11:16:47'),
(186, 'donminick', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 1, '2019-05-02 11:17:07'),
(187, 'donminick', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 1, '2019-05-02 11:18:21'),
(188, 'donminick', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 1, '2019-05-02 11:19:23'),
(189, 'donminick', 'pc1', 'wqeeqe', '1', '2133', 'px.png', 1, '2019-05-02 11:20:41'),
(190, 'donminick', 'pc1', 'wqeeqe', '1', '2133', 'px.png', 1, '2019-05-02 11:21:19'),
(191, 'donminick', 'pc1', 'wqeeqe', '1', '2133', 'px.png', 1, '2019-05-02 11:22:07'),
(192, 'donminick', 'pc1', 'wqeeqe', '1', '2133', 'px.png', 1, '2019-05-02 11:22:37'),
(193, 'donminick', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 1, '2019-05-02 11:23:06'),
(194, 'donminick', '7 Buttons LED', '<p>Optical Wireless Gaming Mouse For Win7/8 ME XP, 2400 DPI /1600 DPI /1000 DPI /600 DPI&nbsp;</p>\r\n', '1', '1900', 'mosuess.png', 1, '2019-05-02 11:24:45'),
(195, 'donminick', '7 Buttons LED', '<p>Optical Wireless Gaming Mouse For Win7/8 ME XP, 2400 DPI /1600 DPI /1000 DPI /600 DPI&nbsp;</p>\r\n', '1', '1900', 'mosuess.png', 1, '2019-05-02 11:25:59'),
(196, 'donminick', '7 Buttons LED', '<p>Optical Wireless Gaming Mouse For Win7/8 ME XP, 2400 DPI /1600 DPI /1000 DPI /600 DPI&nbsp;</p>\r\n', '1', '1900', 'mosuess.png', 1, '2019-05-02 11:54:49'),
(197, 'donminick', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 1, '2019-05-02 11:55:37'),
(198, 'donminick', 'pc1', 'wqeeqe', '1', '2133', 'px.png', 1, '2019-05-02 11:55:56'),
(199, 'donminick', 'pc1', 'wqeeqe', '1', '2133', 'px.png', 1, '2019-05-02 11:56:22'),
(200, 'donminick', '7 Buttons LED', '<p>Optical Wireless Gaming Mouse For Win7/8 ME XP, 2400 DPI /1600 DPI /1000 DPI /600 DPI&nbsp;</p>\r\n', '1', '1900', 'mosuess.png', 1, '2019-05-02 11:58:46'),
(201, 'donminick', 'PICTEK Gaming Mouse121', '<p>PICTEK Gaming Mouse Wired, 8 Programmable Buttons, Chroma RGB Backlit, 7200 DPI Adjustable</p>\r\n', '1', '2000', 'mouse1.png', 1, '2019-05-02 11:58:49'),
(202, 'donminick', '7 Buttons LED', '<p>Optical Wireless Gaming Mouse For Win7/8 ME XP, 2400 DPI /1600 DPI /1000 DPI /600 DPI&nbsp;</p>\r\n', '1', '1900', 'mosuess.png', 1, '2019-05-02 11:59:48'),
(203, 'donminick', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 1, '2019-05-02 12:00:08'),
(204, 'donminick', '7 Buttons LED', '<p>Optical Wireless Gaming Mouse For Win7/8 ME XP, 2400 DPI /1600 DPI /1000 DPI /600 DPI&nbsp;</p>\r\n', '1', '1900', 'mosuess.png', 1, '2019-05-02 12:00:22'),
(205, 'donminick', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 1, '2019-05-02 12:16:18'),
(206, 'donminick', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 1, '2019-05-02 12:27:32'),
(207, 'donminick', '7 Buttons LED', '<p>Optical Wireless Gaming Mouse For Win7/8 ME XP, 2400 DPI /1600 DPI /1000 DPI /600 DPI&nbsp;</p>\r\n', '1', '1900', 'mosuess.png', 1, '2019-05-02 12:27:36'),
(208, 'donminick', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 1, '2019-05-02 12:47:50'),
(211, 'donminick', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 1, '2019-05-02 13:47:19'),
(212, 'donminick', '7 Buttons LED', '<p>Optical Wireless Gaming Mouse For Win7/8 ME XP, 2400 DPI /1600 DPI /1000 DPI /600 DPI&nbsp;</p>\r\n', '1', '1900', 'mosuess.png', 1, '2019-05-02 13:50:40'),
(213, 'donminick', '7 Buttons LED', '<p>Optical Wireless Gaming Mouse For Win7/8 ME XP, 2400 DPI /1600 DPI /1000 DPI /600 DPI&nbsp;</p>\r\n', '1', '1900', 'mosuess.png', 1, '2019-05-03 02:34:24'),
(214, 'donminick', '7 Buttons LED', '<p>Optical Wireless Gaming Mouse For Win7/8 ME XP, 2400 DPI /1600 DPI /1000 DPI /600 DPI&nbsp;</p>\r\n', '1', '1900', 'mosuess.png', 1, '2019-05-03 02:51:31'),
(215, 'donminick', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 1, '2019-05-03 02:59:11'),
(216, 'donminick', 'PICTEK Gaming Mouse121', '<p>PICTEK Gaming Mouse Wired, 8 Programmable Buttons, Chroma RGB Backlit, 7200 DPI Adjustable</p>\r\n', '1', '2000', 'mouse1.png', 1, '2019-05-03 02:59:14'),
(217, 'donminick', '7 Buttons LED', '<p>Optical Wireless Gaming Mouse For Win7/8 ME XP, 2400 DPI /1600 DPI /1000 DPI /600 DPI&nbsp;</p>\r\n', '1', '1900', 'mosuess.png', 1, '2019-05-03 02:59:17'),
(218, 'donminick', 'pc1', 'wqeeqe', '1', '2133', 'px.png', 1, '2019-05-03 02:59:20'),
(219, 'donminick', 'pc1', 'wqeeqe', '1', '2133', 'px.png', 1, '2019-05-03 03:07:47'),
(220, 'donminick', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 1, '2019-05-03 03:57:20'),
(221, 'donminick', '7 Buttons LED', '<p>Optical Wireless Gaming Mouse For Win7/8 ME XP, 2400 DPI /1600 DPI /1000 DPI /600 DPI&nbsp;</p>\r\n', '1', '1900', 'mosuess.png', 1, '2019-05-03 04:00:44'),
(222, 'donminick', '7 Buttons LED', '<p>Optical Wireless Gaming Mouse For Win7/8 ME XP, 2400 DPI /1600 DPI /1000 DPI /600 DPI&nbsp;</p>\r\n', '1', '1900', 'mosuess.png', 1, '2019-05-03 04:00:54'),
(223, 'asds', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 0, '2019-05-03 05:38:07'),
(224, 'asds', '7 Buttons LED', '<p>Optical Wireless Gaming Mouse For Win7/8 ME XP, 2400 DPI /1600 DPI /1000 DPI /600 DPI&nbsp;</p>\r\n', '1', '1900', 'mosuess.png', 0, '2019-05-03 05:38:10'),
(228, 'donminick', '7 Buttons LED', '<p>Optical Wireless Gaming Mouse For Win7/8 ME XP, 2400 DPI /1600 DPI /1000 DPI /600 DPI&nbsp;</p>\r\n', '1', '1900', 'mosuess.png', 1, '2019-05-03 06:13:31'),
(229, 'donminick', 'adad12', 'dada', '1', '22222', 'gamingmonitor.png', 1, '2019-05-03 06:13:36'),
(231, 'donminick', 'allen', 'allen', '1', '123', '1_(2).jpg', 0, '2019-05-14 11:02:10'),
(232, 'donminick', '123', '213', '1', '123', '1_(2)520.jpg', 0, '2019-05-14 11:02:13');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `date_created`) VALUES
(1, 'Electronic', '2019-04-05 06:45:34'),
(2, 'Electronic Tools', '2019-04-05 06:45:34'),
(3, 'Cellphone', '2019-04-05 06:45:34'),
(4, 'Laptops', '2019-04-05 06:45:34'),
(5, 'shampoo', '2019-04-05 06:45:34'),
(8, 'Mouse', '2019-04-05 06:45:34'),
(9, 'Keyboard', '2019-04-09 09:44:16');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(1200) NOT NULL,
  `quantity` varchar(200) NOT NULL,
  `price` varchar(200) NOT NULL,
  `upload_photo` varchar(1000) NOT NULL,
  `date_posted` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `category` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=318 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `description`, `quantity`, `price`, `upload_photo`, `date_posted`, `category`) VALUES
(317, 'jasonmanas', 'ahdakjhdajhdjk', '1000', '1000', 'keyboard1.png', '2019-05-15 14:00:20', '');

-- --------------------------------------------------------

--
-- Table structure for table `sale`
--

CREATE TABLE IF NOT EXISTS `sale` (
  `id` int(11) NOT NULL,
  `product` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `session` varchar(255) NOT NULL,
  `date_sale` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sale`
--

INSERT INTO `sale` (`id`, `product`, `price`, `session`, `date_sale`, `status`, `number`) VALUES
(4, '            Gaming Monitor            Gaming Keyboard            shampoo                        ', '4120', 'donminick', '2019-04-08 04:06:56', '1', ''),
(5, '            Gaming Keyboard            shampoo                        ', '2120', 'donminick', '2019-04-08 05:52:39', '1', ''),
(6, '            Gaming Monitor                        ', '2000', 'donminick', '2019-04-08 07:05:44', '', ''),
(7, '            hp laptop            apple 1                        ', '40300', 'allenjr', '2019-04-08 10:16:29', '', ''),
(8, '            Gaming Keyboard            shampoo            hp laptop            linux_acer laptop                        ', '36420', 'donminick', '2019-04-08 11:05:32', '', ''),
(10, '            hp_laptop            hp_laptop                        ', '60900', 'donminick', '2019-04-09 05:22:04', '1', '09462536385'),
(11, '            hp_laptop                        ', '20300', 'donminick', '2019-04-09 07:56:28', '1', '09272606707'),
(12, '            samsung laptop            motorola                        ', '82800', 'lyewee', '2019-04-09 09:16:56', '1', '09462536385'),
(13, '            samsung laptop            hp laptop                        ', '76600', 'lyewee', '2019-04-09 09:23:43', '1', '09462536385'),
(14, '            linux acer laptop            Sound BlasterX Vanguard K08                        ', '41000', 'donminick', '2019-04-09 09:47:53', '1', '09272606707'),
(15, '            Sound BlasterX Vanguard K08                        ', '9000', 'lyewee', '2019-04-09 09:59:23', '1', '09462536385');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `fone` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `address`, `type`, `fone`) VALUES
(1, 'butch', '12345', '', '', 'admin', ''),
(2, 'asds', 'fds', 'sdfsf@yahoo.com', 'sdf', 'costumer', ''),
(3, 'donminick', '12345', 'donminick120@gmail.com', 'Cogunan Nasugbu, Batangas', 'costumer', '09272606707'),
(4, 'admin', '12345', '', '', 'admin', ''),
(5, 'allenjr', '12345', 'aj45@yahoo.com', 'brgy 8 nasugbu batangas', 'costumer', ''),
(6, 'lyewee', '12345', 'lyewleen1232@yahoo.com', 'biga calatagan, batangas', 'costumer', '09462536385');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `billing`
--
ALTER TABLE `billing`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sale`
--
ALTER TABLE `sale`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `billing`
--
ALTER TABLE `billing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=82;
--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=233;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=318;
--
-- AUTO_INCREMENT for table `sale`
--
ALTER TABLE `sale`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
